# Aegis Platform

Autonomous web-security testing and CTF-solving platform.
**Part 1 of 8: foundation, repository, runtime, data model, security
boundaries and core contracts — implemented, built and tested.**
**Part 2 of 8: the Agent Operating System — strategic leader, tactical
workers, task compiler, scheduler, hypothesis engine, autonomous loop —
implemented, built and tested.**
**Part 3 of 8: the interaction layer — HTTP engine with SSRF defence,
controlled mutation + replay, Playwright browser service with
identity-isolated contexts, network capture promoted to shared request
records, multi-identity sessions, HAR import, artifact retrieval —
implemented, built and tested.**
**Part 5 of 8: the security knowledge & web research system — hybrid
retrieval, curated sources, CTF case memory, bounded live research,
provenance and prompt-injection isolation.**
extraction (endpoints/parameters/authorization matrix/objects/workflows/
data flows), security signals, competing hypothesis candidates, test
planning with information gain, semantic differential testing, skeptical
verification with alternative explanations — implemented, built and
tested.**

> **Authorized use only.** This platform is built for authorized penetration
> testing, local security laboratories, intentionally vulnerable
> applications and CTF environments. Every engagement requires an explicit,
> deterministic scope; nothing outside that scope can be contacted by any
> tool, worker, or model decision.

## What Part 1 includes (real, runnable)

- **Monorepo** (npm workspaces, TypeScript ESM): Fastify API, React+Vite UI,
  10 packages, 6 services, hash-verified SQL migrations (12 in Part 1)
- **Deterministic scope enforcement** — allowlist checker (hosts, domains,
  ports, schemes, exclusions), applied to every target and every network
  tool call; the model cannot bypass it
- **Engagement lifecycle** — PENTEST/CTF modes, state machine
  (DRAFT→READY→RUNNING⇄PAUSED→COMPLETED/FAILED/CANCELLED), events, audit
- **Auth** — scrypt passwords, hashed bearer tokens, per-route ownership
  (404 for cross-tenant), rate limiting, security headers
- **Evidence** — immutable, SHA-256-addressed object store with tamper
  verification and derived-evidence chains
- **Secrets** — AES-256-GCM secret store; DB/logs hold only `SEC_…`
  references; redaction engine over all structured logs
- **Abstractions for Parts 2–8** — tool registry + permission/scope
  gateway (1 real tool: `parser.jwt`), model provider interface (mock +
  Google REST), event bus, job queue, orchestrator, worker interfaces

## What Part 2 adds (real, runnable)

- **Agent Operating System** (`services/agent`): leader runtime, decision
  validator (7 deterministic layers), task compiler (compact packets,
  retrieval, context splitting), dependency-aware + quota-aware scheduler,
  hypothesis engine (competing hypotheses, branching, budgeted),
  result normalizer, anti-loop + oscillation detection, crash recovery,
  metrics, and the **event-driven autonomous loop** (explicit state machine,
  deterministic stop conditions — never uncontrolled recursion)
- **Real tactical worker runtime** (`services/worker-runtime`): bounded
  tool loop, allow-list-only tool requests, structured turns, NEEDS_*
  statuses, per-attempt persistence
- **9-value strategic decision vocabulary** — strict discriminated-union
  zod schemas; malformed/injected model output fails closed
- **Prompt trust separation** — every prompt is five labeled sections;
  target-derived text only ever appears inside
  `<UNTRUSTED_TARGET_DATA>` delimiters; persisted messages record
  `untrusted_bytes` for audit
- **Hypothesis-driven reasoning** — persistent hypotheses with
  evidence-event confidence updates, dead-end memory, test-registry
  fingerprint dedup, verification-gated finding promotion
  (HYPOTHESIS→TESTING→SUPPORTED→VERIFICATION→CONFIRMED FINDING)
- **Quota + budget management** — RPM/TPM/RPD sliding windows, separate
  token budgets per purpose (leader/worker/knowledge/summarization/
  verification), per-engagement resource budgets
- **15 new tables** (27 total), full HTTP API for runs/tasks/hypotheses/
  strategies/dead-ends/observations/findings/metrics + audited human
  overrides + crash recovery endpoint
- **Web UI**: agent tab (run control, hypotheses, tasks, strategies, dead
  ends, metrics) and a real findings tab

## What Part 3 adds (real, runnable)

- **HTTP engine** (`@aegis/target-http`): normalized request/response
  model shared by engine AND browser capture; JSON/form/multipart/text/
  XML/binary bodies; redirect following with **per-hop scope + network
  re-validation**; response size limits with explicit truncation flags;
  per-engagement/per-host rate limiting + bounded concurrency
- **SSRF defence** (§49-§52): scheme allowlist, DNS resolution + IP
  classification (loopback/private/link-local denied in production,
  lab policy for fixtures), malformed-URL rejection
- **Controlled mutation + replay** (§19-§22, §69-§72): structured
  mutations (query/header/cookie/JSON-path/form/method/path) create NEW
  immutable requests; originals never change; scope re-validated on
  execution
- **Browser service** (`@aegis/browser`, Playwright): per-engagement
  browser, **one isolated context per identity** (anonymous included),
  16 deterministic actions with semantic selectors, structured event
  stream, network capture promoted into HTTP records, DOM snapshots +
  diffs, cookies/storage captured into the secret store (values never
  stored), downloads as untrusted sha256 evidence, WebSocket
  observation, screenshots, finally-style cleanup
- **Session manager** (`@aegis/session-manager`): identity → auth state
  (cookies/bearer/JWT/custom headers/browser storage), injection at use
  time, expiration detection (401/403/auth-redirect/logout) as
  observations — never auto re-authentication; login workflows recorded
  as reusable identity sessions
- **Toolbox** (`@aegis/toolbox`): 23 real tools — `http.request/replay/
  mutate`, `browser.navigate/click/fill/submit/snapshot/screenshot/…`,
  `websocket.observe`, `artifact.read/extract/search`, `har.import` —
  each zod-schema'd, risk-classified, versioned, audit-logged with
  redacted input (§43-§47, §78)
- **13 new tables** (40 migrations total), 20 new API endpoints, HAR
  import with scope filtering, tool-execution audit log

**383 automated tests** (unit / integration / security / e2e — including
real-Chromium browser suites against a local lab fixture app) + a
43-check smoke test, all green.


## What Part 4 adds (real, runnable)

- **Security reasoning engine** (`@aegis/reasoning`): transforms recorded
  traffic into a structured security model — endpoints canonicalized and
  deduplicated by fingerprint (`/api/orders/1` + `/api/orders/2` →
  `/api/orders/{param}`), parameter registry with deterministic value
  characteristics (UUID/JWT/timestamp/…) and semantic candidates,
  authorization matrix (identity × endpoint × object × outcome), object
  candidates with ownership, workflow reconstruction from observed
  sequences, data flows, and a persistent attack-surface graph
- **Security signals, not findings** (§136): the deterministic signal
  engine emits CROSS_IDENTITY_DIFFERENCE, CROSS_IDENTITY_OBJECT_REFERENCE,
  AUTH_STATE_CHANGE, REFLECTED_INPUT, ERROR_DISCLOSURE, TOKEN_PATTERN,
  STATE_TRANSITION_ANOMALY, UNUSUAL_RESPONSE_DIFFERENCE, … — every signal
  states it is not a conclusion
- **Hypothesis candidates with competing interpretations** (§44-§47): every
  suspicious signal yields a primary hypothesis PLUS alternatives (public
  object / shared access / cache), each with required evidence and
  distinguishing tests
- **Test planning** (§48-§50, §118): deterministic fingerprints, explicit
  preconditions (scope, identity, baseline, duplicate), expected
  information gain that ranks tests by how well they separate competing
  hypotheses — the Part 2 scheduler seam
- **Differential engine** (§24-§28): semantic JSON/HTML/binary comparison
  with volatile-field marking (timestamps/CSRF tokens marked, never
  deleted), structural diffs, similarity scoring
- **Skeptical verification** (§70-§75): tries to REFUTE first — anonymous
  access, caching, shared access, reproduction, baseline comparison —
  alternatives preserved for audit, dead ends recorded with reasons,
  INCONCLUSIVE is a valid outcome
- **Leader projection** (§120): compact, trust-separated security context
  (counts and ids trusted; target-derived strings inside
  UNTRUSTED_TARGET_DATA delimiters) feeding the Part 2 leader prompt
- **3 worker tools**: `reasoning.query` (§80 focused attack-surface view),
  `differential.compare`, `verification.evaluate` — all READ_ONLY,
  engagement-bound, gateway-gated
- **16 API routes** under `/api/engagements/:id/reasoning/*` + 11 new
  migrations (041-051, 51 total) + 103 new tests (486 total)

## What is explicitly NOT implemented yet (by design)

Reporting (Part 6+); test candidates are PLANNED deterministically — the
Part 2 leader/scheduler decides execution. Knowledge retrieval is REAL
since Part 5 (see below).

## What Part 5 adds (real, runnable)

* **Knowledge base**: 12-table data model — curated source registry
  (OWASP WSTG/ASVS/API Top 10, PortSwigger, MDN, RFCs, CTF feeds),
  versioned documents with provenance, semantic chunks with heading
  paths, structured security techniques, extracted CVE/CWE/OWASP
  references, query audit rows, persisted scored results, research
  tasks and an index-version marker.
* **Ingestion pipeline** (§115): HTML/Markdown/TXT/JSON/XML/PDF parsers
  (a dependency-free PDF text extractor), sanitization (scripts removed,
  code preserved), deterministic metadata extraction, semantic chunking
  (300-800 token targets, code blocks separate), content hashing,
  PostgreSQL FTS indexing and best-effort embeddings (failure keeps the
  document keyword-searchable).
* **Hybrid retrieval** (§15-§25): keyword (PG full-text) + semantic
  (deterministic hashing embeddings by default, Google embeddings
  optional), merged and deduplicated, reranked with configurable
  weights — relevance, trust, freshness (CTF-aware decay), context,
  specificity, duplicate penalty; corroboration detection and PRESERVED
  source disagreement.
* **Compact packets** (§61-§63): token-bounded (leader ≤ 2500, worker
  ≤ 1200 tokens), primary + one corroborating source per concept,
  provenance on every result; rendered inside
  `<UNTRUSTED_EXTERNAL_KNOWLEDGE>` delimiters with a knowledge-usage
  policy — prompt injection in public pages stays inert data.
* **Case memory** (§36-§42): CTF write-ups with structured fields and
  deterministic pattern extraction (technique/precondition/signal/test
  pattern/verification/false-positive); riddle clue → concept candidates
  (PATTERN_RETRIEVAL); EXACT_CASE_RETRIEVAL stays a distinct benchmark
  mode.
* **Bounded live research** (§26-§33, §72): SSRF-defended fetcher (DNS
  before connection, loopback/private denial, redirect re-validation,
  size/time/rate/daily budgets), research planner, trust-ranked source
  selection, relevant-section extraction, corroboration/disagreement
  — all audited; no configured search provider → honest empty results.
* **Agent integration** (§120): the leader context carries a compact,
  trust-separated knowledge packet derived from active hypotheses;
  workers call the four `knowledge.*` tools (live web tools fail closed
  without the `knowledgeWeb` permission, §84).
* **Evaluation** (§96-§98): Recall@K / Precision@K / MRR / NDCG /
  duplicate-rate metrics + agent-utility metrics surfaced on
  `/api/knowledge/status`; the §127 query set runs as a retrieval
  benchmark in the integration suite.

Honest boundaries: reporting (Part 6); the Part 6 engine will combine
Parts 2-5 into the long-running autonomous loop.
intelligence, authz mapping, differential testing), vulnerability-
specific workers, source analysis. Registered interfaces return clear
`NOT_IMPLEMENTED` errors; the UI marks them honestly.

## Quick start

```bash
npm install
cp .env.example .env
npx playwright-core install chromium   # browser binaries (Part 3)
npm run db:ensure      # starts embedded PostgreSQL on 127.0.0.1:5433
npm run db:migrate
npm run dev:api        # :4000
npm run dev:web        # :5173 (proxies /api)
```

Then: register → create project → create engagement → configure scope →
add target (out-of-scope targets are rejected) → start → *Start agent run*
(agent tab). With the default mock model providers the loop mechanics run
but decisions are rejected as non-JSON (honest mock behaviour); configure
`STRATEGIC_MODEL_PROVIDER=google` + `GOOGLE_API_KEY` for real reasoning.

## Commands

| Command | Purpose |
|---|---|
| `npm run typecheck` / `lint` / `build` | quality gates |
| `npm run test` | all 575 tests (starts DB automatically) |
| `npm run test:unit / :integration / :security / :e2e` | individual suites |
| `npx tsx scripts/smoke.ts` | 61-check end-to-end smoke test |
| `npm run db:start / stop / ensure / migrate / reset` | embedded PostgreSQL lifecycle |

## Docs

- [Architecture overview](docs/architecture/overview.md)
- [Security boundaries](docs/architecture/boundaries.md)
- [Data model](docs/architecture/data-model.md)
- [Event system](docs/architecture/events.md)
- [Threat model](docs/security/threat-model.md)
- [API reference](docs/api/README.md)
- [Development guide](docs/operations/development.md)

## Stack

TypeScript (strict) · Fastify 4 · React 18 + Vite 5 · PostgreSQL (pg) ·
zod contracts (shared FE/BE) · vitest · typescript-eslint 9
