export * from './knowledge.js';
